import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Shared Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Allowed models according to guidelines
const VALID_CHAT_MODELS = [
  'gemini-3.5-flash',
  'gemini-3.1-flash-lite',
  'gemini-3.1-pro-preview',
];

// Multi-turn Gemini Chat endpoint
app.post('/api/gemini/chat', async (req, res) => {
  try {
    const { messages, systemInstruction, model } = req.body;

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Messages array is required' });
    }

    const selectedModel = VALID_CHAT_MODELS.includes(model)
      ? model
      : 'gemini-3.5-flash';

    // Format messages for @google/genai generateContent
    // role must be 'user' or 'model'
    const formattedContents = messages.map((m: { role: string; content: string }) => ({
      role: m.role === 'assistant' || m.role === 'model' ? 'model' : 'user',
      parts: [{ text: m.content || '' }],
    }));

    const response = await ai.models.generateContent({
      model: selectedModel,
      contents: formattedContents,
      config: {
        systemInstruction:
          systemInstruction ||
          'You are StudySprint AI, an elite academic mentor and expert tutor for SBTE Bihar Diploma in Computer Science & Engineering (5th Semester). You specialize in Java Programming, Software Engineering, Computer Networks, Python, and Cloud Computing. You explain concepts with clear definitions, diagrams, code examples, numerical steps, and structured 4-mark/6-mark answers tailored for State Board of Technical Education (SBTE) Bihar examinations. You can communicate in clear English and Hinglish as preferred by students.',
      },
    });

    res.json({
      reply: response.text || 'No response generated.',
      modelUsed: selectedModel,
    });
  } catch (err: any) {
    console.error('Chat error:', err);
    res.status(500).json({
      error: err.message || 'Failed to generate chat response',
    });
  }
});

// Audio transcription endpoint using gemini-3.5-transcribe
app.post('/api/gemini/transcribe', async (req, res) => {
  try {
    const { audioBase64, mimeType } = req.body;

    if (!audioBase64) {
      return res.status(400).json({ error: 'audioBase64 string is required' });
    }

    const cleanBase64 = audioBase64.replace(/^data:audio\/\w+;base64,/, '');

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-transcribe',
      contents: [
        {
          inlineData: {
            mimeType: mimeType || 'audio/webm',
            data: cleanBase64,
          },
        },
        'Transcribe the audio accurately into clear text. Do not add conversational commentary, just return the transcription.',
      ],
    });

    const transcript = response.text?.trim() || '';

    res.json({
      transcript,
      modelUsed: 'gemini-3.5-transcribe',
    });
  } catch (err: any) {
    console.error('Transcription error:', err);
    res.status(500).json({
      error: err.message || 'Failed to transcribe audio',
    });
  }
});

// Smart Study Plan generator endpoint
app.post('/api/gemini/study-plan', async (req, res) => {
  try {
    const {
      subjects,
      topics,
      examDate,
      dailyHours,
      goal,
      currentKnowledgeLevel,
    } = req.body;

    const prompt = `Create a structured, personalized study schedule for a student.
Parameters:
- Subjects: ${JSON.stringify(subjects || ['General Studies'])}
- Topics to cover: ${JSON.stringify(topics || [])}
- Target Exam / Deadline Date: ${examDate || 'Next 30 days'}
- Available Daily Study Time: ${dailyHours || 3} hours/day
- Student Goal: ${goal || 'Achieve high score and deep mastery'}
- Knowledge Level: ${currentKnowledgeLevel || 'Intermediate'}

Create a realistic day-by-day plan with prioritized study sessions, specific focus areas, active recall intervals, and rest/revision slots.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        systemInstruction:
          'You are an expert curriculum designer and learning psychologist. Return a valid JSON study plan.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            summary: { type: Type.STRING },
            totalDays: { type: Type.INTEGER },
            dailyTargetMinutes: { type: Type.INTEGER },
            strategyTips: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            sessions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  dayNumber: { type: Type.INTEGER },
                  dateOffsetDays: { type: Type.INTEGER },
                  subject: { type: Type.STRING },
                  topic: { type: Type.STRING },
                  durationMinutes: { type: Type.INTEGER },
                  priority: { type: Type.STRING },
                  objectives: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                  studyTechnique: { type: Type.STRING },
                },
                required: ['dayNumber', 'subject', 'topic', 'durationMinutes', 'priority'],
              },
            },
          },
          required: ['title', 'summary', 'sessions', 'strategyTips'],
        },
      },
    });

    const parsedPlan = JSON.parse(response.text || '{}');
    res.json({ plan: parsedPlan });
  } catch (err: any) {
    console.error('Study plan error:', err);
    res.status(500).json({
      error: err.message || 'Failed to generate study plan',
    });
  }
});

// PDF Analysis / Q&A / Summary endpoint
app.post('/api/gemini/analyze-pdf', async (req, res) => {
  try {
    const { title, textSnippet, query, action } = req.body;

    let prompt = '';
    if (action === 'summary') {
      prompt = `Provide a concise executive summary and key takeaways for this study document titled "${title}":\n\n${textSnippet}`;
    } else if (action === 'flashcards') {
      prompt = `Generate 5 high-yield question & answer flashcard pairs based on this material from "${title}":\n\n${textSnippet}`;
    } else if (action === 'quiz') {
      prompt = `Create a 3-question multiple-choice practice quiz with correct answers and explanations based on this material from "${title}":\n\n${textSnippet}`;
    } else {
      prompt = `Based on the following study document titled "${title}", answer the student's question accurately.\nQuestion: ${query}\n\nDocument Context:\n${textSnippet}`;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        systemInstruction:
          'You are a high-level academic tutor helping a student deeply understand their uploaded PDF study materials.',
      },
    });

    res.json({ result: response.text || '' });
  } catch (err: any) {
    console.error('PDF Analysis error:', err);
    res.status(500).json({
      error: err.message || 'Failed to analyze PDF content',
    });
  }
});

// Download project zip endpoint
app.get('/api/download-zip', (_req, res) => {
  const zipPath = path.resolve(__dirname, 'OmniStudy-source-code.zip');
  res.download(zipPath, 'OmniStudy-source-code.zip', (err) => {
    if (err) {
      console.error('Download zip error:', err);
      if (!res.headersSent) {
        res.status(500).send('Could not download zip file');
      }
    }
  });
});

// Download Spring Boot + HTML/CSS/JS zip endpoint
app.get('/api/download-spring-boot-zip', (_req, res) => {
  const zipPath = path.resolve(__dirname, 'spring-boot-omnistudy.zip');
  res.download(zipPath, 'spring-boot-omnistudy.zip', (err) => {
    if (err) {
      console.error('Download Spring Boot zip error:', err);
      if (!res.headersSent) {
        res.status(500).send('Could not download Spring Boot zip file');
      }
    }
  });
});

// Vite middleware for dev / static for production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT} (Prod: ${isProd})`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
