export interface StudyMaterial {
  id: string;
  userId: string;
  title: string;
  subject: string;
  topic: string;
  content: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
}

export interface PdfDocument {
  id: string;
  userId: string;
  title: string;
  fileName: string;
  fileSize: number;
  pageCount: number;
  extractedText: string;
  topics: string[];
  subject: string;
  createdAt: string;
  updatedAt: string;
}

export interface StudyTask {
  id: string;
  userId: string;
  title: string;
  subject: string;
  topic: string;
  dueDate: string;
  priority: 'low' | 'medium' | 'high';
  status: 'pending' | 'in_progress' | 'completed';
  estimatedMinutes?: number;
  completedAt?: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface StudyPlanSession {
  dayNumber: number;
  dateOffsetDays: number;
  subject: string;
  topic: string;
  durationMinutes: number;
  priority: 'low' | 'medium' | 'high';
  objectives?: string[];
  studyTechnique?: string;
  completed?: boolean;
}

export interface StudyPlan {
  id: string;
  userId: string;
  title: string;
  examDate: string;
  dailyStudyHours: number;
  subjects: string[];
  schedule: StudyPlanSession[];
  status: 'active' | 'archived';
  createdAt: string;
  updatedAt: string;
  summary?: string;
  strategyTips?: string[];
}

export interface StudySession {
  id: string;
  userId: string;
  subject: string;
  topic: string;
  durationMinutes: number;
  sessionDate: string; // YYYY-MM-DD
  completedAt: string;
  notes?: string;
  createdAt: string;
}

export interface UserStats {
  userId: string;
  currentStreak: number;
  longestStreak: number;
  lastStudyDate: string; // YYYY-MM-DD
  totalStudyMinutes: number;
  completedTasksCount: number;
  updatedAt: string;
}

export interface ChatMessage {
  id: string;
  userId: string;
  role: 'user' | 'model';
  text: string;
  persona?: 'mentor' | 'summarizer' | 'quizmaster' | 'planner' | 'solver';
  modelUsed?: string;
  createdAt: string;
}

export type ViewTab =
  | 'dashboard'
  | 'materials'
  | 'pdfs'
  | 'smart-plan'
  | 'planner'
  | 'tasks'
  | 'timer'
  | 'chat';
